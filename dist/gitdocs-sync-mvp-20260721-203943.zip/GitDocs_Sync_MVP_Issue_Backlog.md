# GitDocs Sync MVP Issue Backlog

## Current Implementation Status

Last updated: 2026-07-21

Implemented locally with tests:

- Issue 01: real GitHub Action entrypoint and clear setup errors
- Issue 02: `.gitdocs-sync.yml` loading, glob ignore rules, oversized-file limit including CJK cost protection
- Issue 03: first-run audit Issue upsert
- Issue 04: authorized `/gitdocs` commands, permission gate, `future-only`
- Issue 05: batched backfill PRs, PR labels, branding footer
- Issue 06: push-triggered incremental PRs
- Issue 07: Markdown protection for front matter, fenced/tilde/indented code blocks, inline code, links, and paragraph-block translation
- Issue 08: Translation Memory only after merge, persisted through reviewable TM PRs
- Issue 09: oversized-file blocking and customer-facing choices
- Issue 10: privacy-safe usage metadata and PR token summary
- Issue 11: Docusaurus demo fixture and live dry-run checklist
- Issue 12: README landing page and troubleshooting docs

Verified in a real GitHub repository:

- Issue 13 partial: live GitHub smoke repo created and run end to end.
- First-run audit Issue verified.
- DeepSeek-first backfill PR verified and merged.
- Duplicate sync after merge did not create a duplicate PR.
- Incremental source-doc update now creates a real translation PR.
- Front matter metadata is preserved in the updated translation branch.
- Earlier live smoke merged incremental PRs updated Translation Memory on `main`; local hardened behavior now opens a TM PR instead of writing directly to `main`.
- Later incremental sync reuses Translation Memory and keeps provider calls low.
- Stale language branch reset has been removed locally; GitDocs Sync now creates a fresh branch when an old branch exists without an open PR.
- Incremental PR wording is now specific to changed source docs, not backfill/missing files.
- Production-risk review fixes are covered by tests: TM segment mismatch skips TM writes, YAML parsing supports inline arrays via `js-yaml`, corrupt TM JSON does not crash, GitHub content writes do not recurse forever, audit `ready` is truly computed, old branches are not force-reset, TM updates do not bypass PR review, provider/GitHub calls have timeouts, audit Issue lookup paginates, GitHub error bodies redact token-like values, and prompts isolate untrusted document content.
- Medium-risk review fixes are covered by tests: GitHub and provider transient retries, incremental PR batching, bounded translation concurrency, per-target Translation Memory reads, collision-safe Markdown placeholders, paragraph-block translation, tilde/indented code preservation, CJK-aware size limits, glob ignore patterns, and stack-aware Action errors.

Still remaining:

- Published Action slug replacement for `your-org/gitdocs-sync@main`.
- Run a fresh live smoke after syncing the local P0/P1 hardening to the smoke repo.
- Decide whether to add a heavier segment-id mechanism later so reviewer-edited translations can be captured even when they intentionally add or remove paragraphs.

**来源：** `GitDocs_Sync_MVP_PRD_V1.1.md`  
**拆解原则：** 每个 issue 都是一个可验收的纵向切片，优先支持真实 GitHub Action 链路，不做假流程、不做 Dashboard、不做历史翻译质量审计。  
**目标用户约束：** 面向文档即产品的商业团队，直击 Docusaurus 多语言文档不同步痛点，控制 MVP 工程量、翻译成本和误触发风险。

---

## Proposed Breakdown

| ID | Title | Type | Blocked by | User stories covered |
|---|---|---|---|---|
| 01 | Run GitDocs Sync from a real GitHub Action | AFK | None | 用户能在真实 GitHub Actions 环境启动 GitDocs Sync |
| 02 | Load `.gitdocs-sync.yml` and validate plan limits | AFK | 01 | 用户能配置源语言、目标语言、目录和忽略规则，并看到清楚错误 |
| 03 | Generate a first-run sync audit Issue | AFK | 02 | 用户首次接入后看到 Missing / Untracked / Oversized / Ready 体检报告 |
| 04 | Confirm first-run scope with `/gitdocs` Issue commands | AFK | 03 | 有权限用户能在 Issue 中确认补翻译范围，无权限用户不能烧额度 |
| 05 | Create batched backfill translation PRs | AFK | 04 | 用户确认后按语言、按批次生成补翻译 PR |
| 06 | Translate only changed Markdown / MDX segments on push | AFK | 02 | 用户修改主语言文档后，只翻译改动段落 |
| 07 | Preserve technical Markdown and MDX structures | AFK | 06 | 翻译不会破坏代码块、front matter、链接 URL 和 MDX/JSX |
| 08 | Write active Translation Memory only after PR merge | AFK | 05, 06 | 只有客户 merge 后的翻译进入 TM，后续可复用 |
| 09 | Enforce overage and oversized-file confirmation flows | AFK | 03, 05, 06 | 超出套餐或单文档上限时不自动烧钱 |
| 10 | Provide privacy-safe logs and usage metadata | AFK | 05, 06 | 后台记录用量和状态，不长期保存客户正文 |
| 11 | Ship the Docusaurus demo repo for real-chain validation | AFK | 05, 06, 08, 09 | 用户和团队能用 demo repo 验证真实 Action 链路 |
| 12 | Publish self-serve onboarding docs and README landing page | AFK | 11 | 用户能从官网/README 自助完成接入 |
| 13 | Validate commercial MVP readiness with success metrics | HITL | 11, 12 | 团队确认是否达到可冷启动获客的 MVP 标准 |

---

## Issue 01: Run GitDocs Sync from a real GitHub Action

**Type:** AFK  
**Blocked by:** None - can start immediately  
**User stories covered:** 用户能在真实 GitHub Actions 环境启动 GitDocs Sync。

## What to build

Create the minimum real GitHub Action entrypoint that can run inside a customer repo, receive the GitHub context, read repo files, and report a clear GitDocs Sync status. This is not a local-only script and not a static demo; it must run in GitHub Actions.

## Acceptance criteria

- [ ] A workflow can invoke GitDocs Sync in a real GitHub repository.
- [ ] The action prints a concise success/failure summary without dumping document content.
- [ ] The action fails clearly when required inputs or permissions are missing.
- [ ] The action can access repository contents using the configured GitHub token.
- [ ] A demo workflow proves the action runs in GitHub Actions, not only locally.

## Blocked by

None - can start immediately.

---

## Issue 02: Load `.gitdocs-sync.yml` and validate plan limits

**Type:** AFK  
**Blocked by:** Issue 01  
**User stories covered:** 用户能配置源语言、目标语言、文档目录、输出目录和忽略规则，并看到清楚错误。

## What to build

Add configuration loading and validation for the MVP fields: `source_lang`, `target_langs`, `docs_dir`, `output_dir`, and `ignore`. Validate that the selected scope fits the active plan limits before any translation work starts.

## Acceptance criteria

- [ ] The action reads `.gitdocs-sync.yml` from repo root.
- [ ] Missing required fields produce a clear, actionable error.
- [ ] `docs_dir`, `output_dir`, and `ignore` affect which files are scanned.
- [ ] Target language count is validated against the active plan.
- [ ] Config validation does not call translation providers or consume quota.

## Blocked by

- Issue 01

---

## Issue 03: Generate a first-run sync audit Issue

**Type:** AFK  
**Blocked by:** Issue 02  
**User stories covered:** 用户首次接入后看到缺失、未追踪、超额和可同步状态。

## What to build

On first run, scan the configured Docusaurus docs and target language directories, classify files as `Missing`, `Untracked`, `Oversized`, or `Ready`, and create or update a GitHub Issue titled `[GitDocs Sync] Translation sync audit`.

## Acceptance criteria

- [ ] The audit classifies files using only lightweight scanning and hashes.
- [ ] The audit does not call translation providers.
- [ ] The Issue includes summary counts, plan limits, suggested commands, and cost warning copy.
- [ ] Full file lists are hidden in collapsible details sections.
- [ ] Re-running the audit updates the existing audit Issue instead of spamming duplicates.
- [ ] The wording avoids claiming historical translation quality or semantic drift detection.

## Blocked by

- Issue 02

---

## Issue 04: Confirm first-run scope with `/gitdocs` Issue commands

**Type:** AFK  
**Blocked by:** Issue 03  
**User stories covered:** 有权限用户能确认补翻译范围，无权限用户不能触发成本。

## What to build

Handle GitHub Issue comments on the sync audit Issue and recognize only fixed commands: `/gitdocs sync all`, `/gitdocs sync zh`, `/gitdocs sync zh,ja`, and `/gitdocs future-only`. Only repo users with write-level permission can trigger follow-up work.

## Acceptance criteria

- [ ] Valid commands are recognized only on the active sync audit Issue.
- [ ] Invalid commands receive a reply listing supported commands.
- [ ] Comments from users without repo write permission do not create PRs or consume quota.
- [ ] The first valid authorized command locks the audit decision to prevent duplicate backfill PRs.
- [ ] `/gitdocs future-only` marks the repo ready for future incremental sync without creating historical backfill PRs.

## Blocked by

- Issue 03

---

## Issue 05: Create batched backfill translation PRs

**Type:** AFK  
**Blocked by:** Issue 04  
**User stories covered:** 用户确认后按语言、按批次生成补翻译 PR。

## What to build

After an authorized sync command, create backfill translation PRs for selected target languages and eligible files. PRs are split by target language and capped at 30 files per PR.

## Acceptance criteria

- [ ] `/gitdocs sync all` creates PRs for all eligible languages within plan limits.
- [ ] `/gitdocs sync zh` creates PRs only for the selected language.
- [ ] `/gitdocs sync zh,ja` creates separate PRs for selected languages.
- [ ] Each PR contains at most 30 files.
- [ ] PR descriptions show batch number, total batches, changed files, skipped files, and review notes.
- [ ] Free users cannot bypass document limits through batching.
- [ ] Branding footer follows the current plan rules.

## Blocked by

- Issue 04

---

## Issue 06: Translate only changed Markdown / MDX segments on push

**Type:** AFK  
**Blocked by:** Issue 02  
**User stories covered:** 用户修改主语言文档后，只翻译改动段落并创建增量 PR。

## What to build

On source docs changes, detect changed Markdown / MDX segments and create target-language incremental PRs containing only the needed updates. The first version should prioritize Docusaurus docs pages over JSON UI strings, blog, OpenAPI, or other frameworks.

## Acceptance criteria

- [ ] Pushes outside the configured docs scope do not trigger translation work.
- [ ] New source docs are detected and translated for enabled target languages.
- [ ] Changed paragraphs, headings, list items, and table rows are detected as translatable segments.
- [ ] Unchanged segments are not sent for translation.
- [ ] Deleted source segments remove corresponding generated target segments when tracked.
- [ ] Incremental PRs are split by target language.

## Blocked by

- Issue 02

---

## Issue 07: Preserve technical Markdown and MDX structures

**Type:** AFK  
**Blocked by:** Issue 06  
**User stories covered:** 翻译不会破坏开发者文档里的代码、链接、front matter 或 MDX 结构。

## What to build

Ensure translation preserves protected structures in Docusaurus Markdown / MDX docs: code blocks, inline code, YAML front matter, links and URLs, HTML, and MDX/JSX components.

## Acceptance criteria

- [ ] Code blocks are copied without translation.
- [ ] Inline code is preserved.
- [ ] YAML front matter is preserved.
- [ ] Link URLs are preserved while link text can be translated when safe.
- [ ] MDX/JSX component tags and props are not corrupted.
- [ ] A regression sample covers common Docusaurus docs syntax.

## Blocked by

- Issue 06

---

## Issue 08: Write active Translation Memory only after PR merge

**Type:** AFK  
**Blocked by:** Issue 05, Issue 06  
**User stories covered:** 只有客户确认过的翻译进入 TM，后续可复用并降低成本。

## What to build

Track generated translation PRs and write active Translation Memory only after a PR is merged. If users modify translations during review, the merged version becomes the accepted TM record.

## Acceptance criteria

- [ ] PR creation does not mark translations as active TM.
- [ ] Merged PRs write source hash, source segment, final translation, target language, engine, status, PR URL, and timestamp.
- [ ] Closed-unmerged PRs do not write active TM.
- [ ] Modified translations in merged PRs are captured as the accepted version.
- [ ] Later runs reuse exact active TM matches without calling translation providers.

## Blocked by

- Issue 05
- Issue 06

---

## Issue 09: Enforce overage and oversized-file confirmation flows

**Type:** AFK  
**Blocked by:** Issue 03, Issue 05, Issue 06  
**User stories covered:** 超出套餐或文件过大时，系统不替用户花钱或做危险截断。

## What to build

Apply plan limits consistently during audit, backfill, and incremental sync. Oversized files and out-of-plan scopes must pause and ask for customer choice instead of silently translating or truncating.

## Acceptance criteria

- [ ] Audit marks oversized files before translation.
- [ ] Backfill refuses to create PRs beyond plan scope without user narrowing or upgrade.
- [ ] Incremental sync pauses oversized-file translation and explains options.
- [ ] No translation provider call occurs for files blocked by plan or size limits.
- [ ] The user-facing message offers clear choices: reduce scope, split file, upgrade, or skip.

## Blocked by

- Issue 03
- Issue 05
- Issue 06

---

## Issue 10: Provide privacy-safe logs and usage metadata

**Type:** AFK  
**Blocked by:** Issue 05, Issue 06  
**User stories covered:** 商业团队可以接入，不担心正文被长期存储或日志泄露。

## What to build

Record only privacy-safe metadata for usage and troubleshooting. Do not persist customer source documents, translated text, or TM contents in the backend.

## Acceptance criteria

- [ ] Logs do not print full source or translated document content.
- [ ] Usage records include repo, plan, language, counts, provider usage, status, and error category.
- [ ] Backend storage excludes source document body, translated body, and Translation Memory content.
- [ ] Error logs identify file path, segment id, and error type without dumping content.
- [ ] Documentation explains what is and is not stored.

## Blocked by

- Issue 05
- Issue 06

---

## Issue 11: Ship the Docusaurus demo repo for real-chain validation

**Type:** AFK  
**Blocked by:** Issue 05, Issue 06, Issue 08, Issue 09  
**User stories covered:** 用户和团队能亲自验证真实 GitHub Action 链路。

## What to build

Create a Docusaurus demo repo that uses the real GitDocs Sync Action and demonstrates first-run audit, authorized Issue command, backfill PR, incremental PR, TM after merge, and overage handling.

## Acceptance criteria

- [ ] The demo repo uses Docusaurus docs with at least two target languages.
- [ ] First run creates a sync audit Issue.
- [ ] A valid `/gitdocs` command creates a real translation PR.
- [ ] A source doc edit creates an incremental PR.
- [ ] A merge updates active TM.
- [ ] An oversized sample shows the correct blocked flow without translation cost.
- [ ] README gives a two-minute path to reproduce the demo.

## Blocked by

- Issue 05
- Issue 06
- Issue 08
- Issue 09

---

## Issue 12: Publish self-serve onboarding docs and README landing page

**Type:** AFK  
**Blocked by:** Issue 11  
**User stories covered:** 用户能从官网或 README 自助完成接入。

## What to build

Write the customer-facing setup path around the real Action: what GitDocs Sync does, why it is not a CMS, required permissions, configuration, first-run audit, `/gitdocs` commands, plan limits, privacy boundary, and troubleshooting.

## Acceptance criteria

- [ ] README headline uses “Auto-sync Docusaurus docs translations.”
- [ ] Setup explains required GitHub permissions in plain language.
- [ ] Setup includes the workflow snippet and `.gitdocs-sync.yml` example.
- [ ] Docs explain first-run audit Issue and command confirmation.
- [ ] Docs explain plan limits and oversized-file behavior.
- [ ] Docs explain privacy boundary: backend does not persist document body or TM.
- [ ] Troubleshooting covers invalid key, missing config, no permission, overage, and provider failure.

## Blocked by

- Issue 11

---

## Issue 13: Validate commercial MVP readiness with success metrics

**Type:** HITL  
**Blocked by:** Issue 11, Issue 12  
**User stories covered:** 团队确认 MVP 是否已经足够拿去冷启动，而不是继续堆功能。

## What to build

Run the real-chain demo against MVP success metrics and decide whether the product is ready for the first cold-start users. This is a human review slice, not another implementation layer.

## Acceptance criteria

- [ ] First-run audit Issue creation is verified in a real GitHub repo.
- [ ] Authorized `/gitdocs` command creates PRs; unauthorized command does not.
- [ ] Backfill PR and incremental PR are both verified.
- [ ] Merge writes active TM and a later run reuses it.
- [ ] Overage blocks translation cost and shows clear choices.
- [ ] README/onboarding is understandable to a non-core engineer stakeholder.
- [ ] The team explicitly decides whether to start Docusaurus Awesome List / HN / Reddit cold-start outreach.

## Blocked by

- Issue 11
- Issue 12
