# GitDocs Sync MVP 产品需求文档

**状态：** V1.1 产品聚焦版  
**更新时间：** 2026-07-15  
**输入来源：** `GitDocs_Sync_MVP_PRD_V1.0.md` + 2026-07-05 最新产品说明  
**本版变化：** 以“文档即产品的商业团队”为唯一核心用户；把开源项目从目标用户改为获客渠道；收紧 MVP 到“监听 GitHub 文档变更 -> 只翻译改动部分 -> 提交翻译 PR”；同步更新定价、防白嫖、裂变、获客与后续迭代边界。

---

## 1. 产品定位

GitDocs Sync 是一个 Git-native 多语言文档同步工具。它不是翻译工具，而是文档 CI/CD 流水线：监听 GitHub repo 中原文文档的变更，识别实际改动的 Markdown 段落，只翻译改动部分，自动提交目标语言翻译 PR，由开发者 review、merge，随后现有文档站自动更新。

**英文一句话：** We keep your documentation consistent across all languages every time you update it.

**官网主标题建议：** Auto-sync Docusaurus docs translations.

**不做什么：**
- 不建站，不托管文档站，不做 CMS
- 不提供在线编辑器
- 不替代开发者 review
- 不离开 GitHub 日常工作流
- 不把“全文机器翻译”当核心价值

## 2. 核心用户

GitDocs Sync 只服务一类核心用户：**文档即产品的商业团队**。

这些团队的文档直接影响获客漏斗第一页、SEO 流量、用户留存、产品评分或开发者转化。他们通常具备以下特征：

- 用 Docusaurus、Mintlify、Nextra 或类似工具搭建产品文档站
- 已经有多语言内容，而不是刚准备做第一版翻译
- 团队规模约 5-30 人
- 至少一个语言版本已经明显落后于主语言版本
- 文档更新频率稳定，翻译滞后会真实影响用户体验
- 决策人能理解“文档不同步会损失转化或支持效率”

**明确不是核心用户：**

| 人群 | 不作为核心用户的原因 |
|---|---|
| 开源维护者 | 通常零预算，适合作为传播渠道，不适合作为付费主线 |
| 技术写作者 | 经常感受到痛点，但多数不掌握购买预算 |
| 出海 PM / 运营 | 有需求但决策链过长，且不一定掌握 GitHub 工作流 |
| 通用翻译需求用户 | 容易把产品拉向编辑器、术语库、人工翻译协作平台 |

### 2.1 第一版默认客户画像

第一版官网、demo repo、冷启动话术和接入教程先默认服务：

- 使用 Docusaurus 的 DevTool / SaaS 团队
- 使用 Docusaurus 管理产品文档
- 已经有或准备维护 2-5 个目标语言
- 主要目标语言是日语、中文、韩语、西班牙语、法语、德语
- 团队希望继续由开发者在 GitHub PR 中确认翻译，而不是把文档交给新的编辑平台

原因：Docusaurus 的 i18n 机制成熟、文件位置清晰、生态更大；日中韩和欧美主要语言更容易对应真实国际化需求。第一版对外话术不限制源语言，产品通过 `source_lang` 支持用户配置主语言，并把“哪些源语言需求最大”作为需求观察项。

## 3. 核心问题

多语言文档最容易坏在“更新之后”。团队通常能完成第一批翻译，但很难长期保持各语言版本一致：

- 主语言文档改了，其他语言版本没人及时同步
- 全文重翻成本高，还容易覆盖人工修订
- 复制到翻译工具再粘回 Markdown 容易破坏代码块、链接、front matter
- 翻译结果脱离 PR review，开发者不信任自动改动
- 文档站已经有构建流程，团队不想再接一个完整 CMS

GitDocs Sync 要解决的是“每次原文更新后，多语言版本自动跟上，并且仍然走开发者熟悉的 PR 审查流程”。

### 3.1 MVP 产品原则

MVP 面向文档即产品的商业团队，必须直击“多语言文档更新后不同步”这个痛点，不做大而全的平台化能力。

优先级规则：

- 优先让客户快速看到同步缺口和翻译 PR，而不是建设完整 Dashboard
- 优先控制翻译成本和误触发风险，而不是追求自动化到极致
- 优先保持 GitHub 工作流原生体验，而不是引入新的编辑平台
- 优先做能推动客户进入同步流程的轻量判断，而不是做历史翻译质量审计
- MVP 不做看起来高级但不直接推动试用、付费或留存的功能
- MVP 必须是真实可运行链路，不用假翻译流程或静态 demo 替代核心产品验证

## 4. MVP 范围

### 4.1 MVP 只做一件事

监听 GitHub repo 的 docs 目录变更，识别 Markdown 中改动的段落，只翻译改动部分，保留技术结构，并以 PR 形式提交翻译。

第一版默认只承诺支持 Docusaurus 文档页中的 Markdown / MDX 内容。Docusaurus 的 JSON UI 文案、侧边栏标题、blog、data files 可以识别为后续扩展，不作为 MVP 验收标准。

### 4.2 MVP 必做

1. **GitHub Action 接入**  
   用户在 repo 中配置 GitHub Action 和 `.gitdocs-sync.yml` 后即可运行。

2. **变更监听**  
   监听指定文档目录，默认 `docs/`。只在文档文件变化时触发。

3. **段落级差异识别**  
   识别 heading、paragraph、list item、table row 等可翻译单位，只处理改动部分。

4. **Markdown 结构保护**  
   保留代码块、YAML front matter、链接、HTML、MDX/JSX 片段和内联代码。

5. **Translation Memory**  
   记录已接受的源段落与翻译结果。完全相同的段落直接复用，近期翻译作为风格参考。只有翻译 PR 被 merge 后，相关翻译才写入“已接受”的 Translation Memory。

6. **自动生成翻译 PR**  
   按目标语言创建或更新 PR，PR 描述展示变更文件、变更段落、复用数量、失败段落和 review 提示。

7. **GitHub OAuth 登录与用量控制**  
   用户通过 GitHub 登录获取服务 key。后台记录仓库、语言数、文档数、单文档字数和异常翻译量。

8. **首次同步体检报告**  
   首次接入时先扫描主语言文档和目标语言文档，报告缺失、未追踪、超额和预计额度消耗。体检报告以 GitHub Issue 形式创建，客户确认后才创建补翻译 PR。

9. **官网与接入文档**  
   提供首页、定价页、接入教程、故障排查和开源计划页。

### 4.3 MVP 不做

- 在线编辑器
- 团队协作工作台
- 自托管版本
- 术语表
- AI 聊天
- 语义 drift 检测
- 人工翻译 marketplace
- 多平台支持（GitLab、Bitbucket 暂不做）
- 复杂 Dashboard 管理能力

## 5. 核心体验流程

### 5.1 新用户接入

1. 用户访问官网，点击 Get Started
2. 使用 GitHub OAuth 登录
3. 系统生成 `GITDOCS_SYNC_KEY`
4. 用户把 key 添加到 repo secrets
5. 用户复制 GitHub Action 配置到 repo
6. 用户创建 `.gitdocs-sync.yml`
7. GitDocs Sync 先创建首次同步体检 GitHub Issue
8. 用户确认要补哪些语言和文件后，系统创建补翻译 PR
9. 后续 docs 目录更新时，GitDocs Sync 自动提交增量翻译 PR

### 5.2 日常使用

1. 开发者修改源语言文档并 push
2. GitHub Action 等待短暂去抖窗口，避免连续 push 反复触发
3. 系统识别实际改动段落
4. 未变化段落不翻译，已存在完全匹配的翻译直接复用
5. 新增或大幅修改的段落调用翻译引擎
6. 结果写入目标语言目录
7. 系统打开或更新翻译 PR
8. 开发者 review、必要时手动修改、merge
9. 文档站沿用原有部署流程自动更新

PR 创建和 PR merge 是两个不同状态：GitDocs Sync 负责生成“待确认翻译 PR”，客户团队自行完成 review 和 merge。只有 merge 后，系统才认为这批翻译被客户接受。

### 5.3 首次同步体检

首次接入不自动全量翻译，也不做历史翻译质量审计。系统先扫描：

- 主语言文档总数
- 每个目标语言已存在的文档数
- 缺失的目标语言文档
- 已存在但尚未被 GitDocs Sync 追踪的目标语言文档
- 单文档是否超过套餐字数上限
- 预计本次补翻译会占用的文档额度和字数额度

体检报告只做轻量判断，不调用翻译模型，不做跨语言语义比对，不判断历史译文质量。

体检分类：

| 分类 | 含义 |
|---|---|
| `Missing` | 主语言有该文档，目标语言文件不存在 |
| `Untracked` | 目标语言文件存在，但 GitDocs Sync 尚未建立同步记录 |
| `Oversized` | 单文档超过当前套餐字数上限 |
| `Ready` | 已由 GitDocs Sync 建立追踪记录，后续可增量同步 |

体检报告以 GitHub Issue 形式展示，标题建议：

```text
[GitDocs Sync] Translation sync audit
```

Issue 内容给客户三个选择：

1. 创建全部可覆盖范围内的补翻译 PR
2. 只选择部分语言或部分文件补翻译
3. 暂不补历史文档，只开启未来增量同步

客户通过在 Issue 中评论固定命令来确认范围：

```text
/gitdocs sync all
/gitdocs sync zh
/gitdocs sync zh,ja
/gitdocs future-only
```

第一版只识别固定命令，不解析自然语言。无效命令由系统回复可用命令列表。体检报告不是正式翻译结果，不消耗翻译额度。只有客户在 Issue 中通过固定命令确认创建补翻译 PR 后，才开始消耗额度。

命令权限规则：

- 只有 repo owner、admin、maintainer 或具备 write 权限的成员可以触发补翻译
- public repo 中，外部用户评论 `/gitdocs` 命令不会消耗额度，也不会创建 PR
- 无权限用户触发命令时，系统只回复“需要 repo 写权限成员确认”
- 同一个体检 Issue 中，确认命令只在首次有效触发时生效，避免重复创建 PR

补翻译 PR 控制：

- 补翻译按目标语言分 PR
- 单个补翻译 PR 默认最多包含 30 个文件，超出时分批创建
- 每个 PR 描述中说明这是第几批、总批次数、预计剩余文件数
- Free 用户如果补翻译范围超过套餐文档数，必须缩小范围或升级，不自动分批白给

Issue 模板：

```markdown
# Translation sync audit

GitDocs Sync scanned your Docusaurus docs and found the current translation status.

## Summary

| Item | Count |
|---|---:|
| Source docs | 126 |
| Target languages | zh, ja |
| Missing files | 42 |
| Untracked files | 58 |
| Oversized files | 3 |
| Ready for incremental sync | 26 |

## Recommended next step

Comment one command:

`/gitdocs sync all`
Create translation PRs for all eligible missing/untracked files within your plan limits.

`/gitdocs sync zh`
Create translation PRs for zh only.

`/gitdocs sync zh,ja`
Create translation PRs for selected languages.

`/gitdocs future-only`
Skip historical backfill and only sync future doc changes.

## Cost and limits

This audit does not consume translation quota. Translation quota is used only after an authorized repo member confirms a sync command.

Files over your plan limit are not translated until you choose to split the file, reduce scope, or upgrade.
```

Issue 模板不展示完整文件长清单。完整清单折叠在 `<details>` 区块中，避免客户一打开 Issue 就被大量路径淹没。

## 6. 功能规格

### 6.1 配置文件

文件位置：repo 根目录 `.gitdocs-sync.yml`

```yaml
source_lang: en
target_langs:
  - zh
  - ja
  - fr

docs_dir: docs/
output_dir: "i18n/{locale}/docusaurus-plugin-content-docs/current/"

ignore:
  - docs/changelog.md
  - docs/internal/**.md
```

MVP 中不开放 glossary、style、debounce_seconds 等高级字段，避免用户一开始就陷入配置。

GitHub workflow 最小权限：

```yaml
permissions:
  contents: write
  pull-requests: write
  issues: write
```

触发事件：

- `push`：用于源文档变更后的增量翻译
- `issue_comment`：用于识别首次同步体检 Issue 中的 `/gitdocs` 确认命令
- `pull_request.closed`：用于在翻译 PR merge 后写入 active Translation Memory

第一版不要求用户安装 GitHub App。GitHub App 可以作为后续降低配置成本的升级方向。

### 6.2 差异引擎

差异引擎要做到：

- 把 Markdown 文档拆成稳定的可翻译段落
- 只翻译新增或明显变更的段落
- 段落移动不触发重翻
- 段落删除时，同步删除对应目标语言段落
- 技术语法结构不进入翻译请求
- 单段变化超过 70% 时整段重翻，避免半新半旧拼接

### 6.3 翻译引擎

MVP 后台可根据语言方向选择不同翻译引擎，但不把选择暴露给用户。用户只关心翻译 PR 是否稳定生成。

默认策略：

| 语言方向 | 默认引擎 | 原因 |
|---|---|---|
| 含中文方向 | DeepSeek V3 | 中文质量与成本更适合 |
| 非中文方向 | GPT-4o-mini | 覆盖广，调用稳定 |

如果某个引擎失败，系统可降级到备用引擎，并在 PR 说明中提示“本次部分内容使用备用引擎，建议 review 时重点检查”。

### 6.4 Translation Memory

Translation Memory 存储在用户 repo 中的 `.gitdocs-sync/tm/` 目录，随 repo 版本控制。

它在 MVP 中承担两件事：

- **完全匹配复用：** 源段落 hash 完全一致时直接复用已接受翻译，不再调用翻译引擎
- **风格参考：** 未命中时取同方向近期翻译作为参考，帮助保持口吻一致

Translation Memory 不是术语表。术语表属于后续功能。

写入规则：PR 创建时可以生成临时候选记录，但不进入 active 状态；PR merge 后才把最终翻译写入 active Translation Memory。如果客户在 PR 中手动修改翻译，以 merge 后的版本为准。

### 6.5 翻译 PR

PR 按目标语言分开创建，避免多语言混在一个 PR 中难以 review。

PR 标题：

```text
[GitDocs Sync] Update {target_language} docs ({N} files)
```

PR 描述应包含：

- 源语言与目标语言
- 变更文件数
- 变更段落数
- 复用 Translation Memory 的数量
- 新翻译数量
- 跳过或失败段落
- reviewer 需要重点检查的提示
- branding footer（按套餐规则展示）

### 6.6 错误处理

| 场景 | 用户看到什么 | 是否阻断 |
|---|---|---|
| key 无效、套餐超额、配置缺失 | Action 失败，并给出明确原因和修复链接 | 是 |
| 单段翻译失败 | PR 中保留旧翻译或标记未更新，并提示检查日志 | 否 |
| 大文档超过限制 | 先暂停本次文件翻译，提示客户选择“只翻译前面可覆盖部分 / 升级 / 放弃本次翻译” | 是 |
| 首次同步超出套餐 | 体检报告中提示超额，让客户选择缩小范围、升级或只开启未来增量同步 | 是 |
| Issue 评论命令无效 | 系统在 Issue 中回复可用命令列表，不创建 PR | 是 |
| Issue 评论者无权限 | 系统回复需要 repo 写权限成员确认，不消耗额度 | 是 |
| 补翻译文件过多 | 按目标语言分批创建 PR，每批最多 30 个文件 | 否 |
| 翻译引擎降级 | PR 中提示本次使用备用引擎 | 否 |
| 超过 50% 段落失败 | 不创建 PR，Action 失败并提示重试 | 是 |

大文档超额不自动替用户决定。因为“只翻译前面”可能造成文档半新半旧，“升级”涉及付费，“放弃”涉及业务优先级，必须由客户确认。

### 6.7 数据与隐私边界

MVP 默认不把客户文档正文长期存储在 GitDocs Sync 后台。

后台可以保存：

- GitHub 用户与 repo 绑定关系
- 套餐、仓库数、语言数、文档数、字数统计
- 翻译调用次数、token / 字符消耗、失败原因分类
- PR、Issue、Action run 的链接和状态

后台不长期保存：

- 源文档正文
- 目标语言译文正文
- Translation Memory 内容
- 客户在 PR 中手动修改后的译文

文档正文和译文只在翻译请求过程中短暂经过 API 代理，最终结果写回客户 repo。Translation Memory 继续存放在客户 repo 的 `.gitdocs-sync/tm/` 中。

日志要求：

- 默认不打印完整源文档或译文
- 错误日志只展示文件路径、段落编号、错误类型和修复建议
- 需要排查单段内容问题时，由客户主动提供相关片段

## 7. 定价模型

| 套餐 | 价格 | 文档数 | 单文档字数上限 | 仓库数 | 语言数 | reviewer |
|---|---:|---:|---:|---:|---:|---:|
| Free | $0/月 | 30 | 1 万字 | 1 | 1 | - |
| Pro | $19/月 | 150 | 2 万字 | 3 | 3 | - |
| Team | $99/月 | 1000 | 3 万字 | 5 | 5 | 10 |
| Enterprise | Custom | 不限 | 不限 | 不限 | 不限 | 不限 |

计量定义：

- **一个文档**：`docs_dir` 下被纳入同步范围的一个 Markdown / MDX 源文件，不含 ignore 规则排除的文件
- **文档数上限**：当前套餐允许被 GitDocs Sync 追踪的源文档数量，不是每月翻译次数
- **单文档字数**：源文档中可翻译正文的字数，不含代码块、front matter、链接 URL 和被保护的 MDX/JSX 结构
- **目标语言数**：同一 repo 中启用同步的目标语言数量
- **补翻译额度消耗**：只有客户确认补翻译并实际创建 PR 时才开始计入；体检报告本身不消耗额度

### 7.1 定价逻辑

- 30 个文档足够小团队试用并感受价值，但做第二语言或较完整文档站会自然触顶
- 150 个文档覆盖典型小团队的 3 个仓库、每仓约 50 个文档
- 1000 个文档覆盖典型 SaaS 或 DevTool 团队的 5 个仓库、每仓约 200 个文档
- 单文档字数上限用于防止用户把整本书塞进一个 Markdown 文件导致成本失控
- Pro 到 Team 是从个人/小团队使用跨到团队协作与 reviewer 管理，不做线性涨价

### 7.2 防白嫖机制

1. **GitHub OAuth 登录**  
   注册门槛高于邮箱，降低批量薅免费额度的可能。

2. **文档数与单文档字数上限**  
   免费额度足够体验，但总量有限，不适合大规模免费翻译。

3. **异常检测**  
   7 天内翻译量超过该 repo 正常更新频率 10 倍时标记审查。

4. **大文档软拒绝**  
   超额部分不硬崩、不白给。系统先暂停该文件翻译，并提示客户选择只翻译可覆盖部分、升级或放弃本次翻译。

5. **GitHub 权限确认**  
   只有具备 repo 写权限的成员才能通过 Issue 命令触发补翻译，避免 public repo 被外部评论消耗额度。

6. **补翻译 PR 分批**  
   首次补历史文档时，每个目标语言每批最多 30 个文件，避免一次 PR 过大导致 review 成本过高。

### 7.3 典型使用量假设

| 团队类型 | 团队规模 | 日均文档更新量 | 月均更新文件量 |
|---|---:|---:|---:|
| 小 SaaS 团队 | 5-15 人 | 0.5-2 个文件 | 10-40 个文件 |
| DevTool 公司 | 15-30 人 | 1-4 个文件 | 20-60 个文件 |

这些团队大多数不是每天大规模重写文档，而是持续修改少量页面。GitDocs Sync 的价值因此不在“便宜地翻译全站”，而在“每次改动后自动补齐所有语言版本”。

## 8. 开源计划

开源项目不是核心付费用户，而是开发者生态获客渠道。

规则：public repo 可以免费使用 GitDocs Sync，但必须在 README 和翻译 PR 描述中保留 “Maintained with GitDocs Sync” 标识。不愿意保留 branding 的项目走正常付费套餐。

按 star 数分级：

| star 数 | 免费权益 |
|---:|---|
| 500 以下 | 30 个文档，跟 Free 一致 |
| 500-5000 | 150 个文档 |
| 5000 以上 | 不限文档数，但保留月度翻译量保护 |

月度免费翻译量上限：每个开源项目每月 20 万字。超额部分可走付费通道，开源项目享五折。

成本边界：即使同时服务 500 个活跃开源项目，也应通过 star 分级、branding 交换、月度翻译量上限和超额付费把月成本控制在可承受范围内。开源计划的判断标准不是单个项目是否付费，而是它能否带来开发者信任和可见品牌露出。

## 9. 裂变机制

所有裂变都应来自用户正常使用产品时的被动传播，不要求用户主动邀请。

### 9.1 PR 评论区自动露出

每次生成翻译 PR 时，PR 描述底部带一行：

```text
This PR was automatically generated by GitDocs Sync. Your documentation is now synced in {N} languages.
```

Free 用户必须保留。Pro 默认开启但可关闭。Team 和 Enterprise 默认关闭。

### 9.2 多语言状态分享卡片

Dashboard 不是 MVP 核心，但上线后可以提供“分享多语言文档状态”按钮，生成包含项目名、已同步语言列表和每语言进度的图片卡片。

此功能放入后续迭代，不阻塞 MVP。

### 9.3 开源项目 branding

开源免费计划的 README 和 PR branding 是交换条件，不是福利。它的目标是让 GitDocs Sync 出现在开发者真实浏览的仓库中。

## 10. 获客策略

### 阶段一：第 1-2 周，拿到前 10 个真实用户

必须先完成：GitHub Action、README landing page、demo repo 两行命令可运行。

渠道：

- Docusaurus Awesome List
- Product Hunt
- Hacker News: `Show HN: I built a GitHub Action that auto-translates Docusaurus docs`
- Reddit: r/docusaurus、r/technicalwriting、r/SaaS
- 5 个文档咨询工作室或独立开发者

### 阶段二：第 3-4 周，从 10 到 100 个用户

- GitHub Marketplace
- 3-5 个开源项目免费嵌入
- SEO 精准卡位：`docusaurus translate docs`、`github action translate markdown`、`automatic documentation translation`

### 阶段三：持续获客

- before/after 展示素材
- Docusaurus starter 模板嵌入
- dev.to / Medium / 自有博客教程

## 11. MVP 交付物

### 11.1 必须能验收的结果

1. 一个真实可运行的 GitHub Action
2. 一个 Docusaurus demo repo，用于验证真实 Action
3. 首次接入后生成同步体检报告
4. 体检 Issue 展示 summary、推荐命令、额度提示和折叠文件清单
5. 具备 repo 写权限的用户用固定命令确认补翻译范围
6. 系统生成目标语言补翻译 PR
7. 无权限用户评论命令时不会消耗额度或创建 PR
8. 用户修改主语言 docs 中一段话并 push
9. GitHub Action 自动运行
10. 系统只翻译改动段落
11. 代码块、front matter、链接不被破坏
12. 系统生成目标语言增量 PR
13. PR 描述清楚说明改了什么
14. merge 后文档站可以沿用原流程更新

不合格的 MVP：

- 只有官网和截图，没有真实 GitHub Action
- 只有 demo repo，没有真实 PR 创建
- 用假翻译结果模拟同步流程
- 只能在本地脚本跑，不能在 GitHub Actions 环境运行

### 11.2 三个 Sprint

**Sprint 1：跑通核心链路**

- Action 触发
- 首次同步体检报告
- Markdown 解析与段落差异识别
- 翻译调用
- 目标语言文件写入
- PR 创建

验收：demo repo 首次接入先创建体检 Issue；用户确认后创建补翻译 PR；后续改一段文档后自动生成增量翻译 PR。

Sprint 1 开发切片：

1. Action 能读取 `.gitdocs-sync.yml`
2. Action 能扫描 Docusaurus `docs_dir` 和目标语言目录
3. Action 能生成轻量体检结果：Missing / Untracked / Oversized / Ready
4. Action 能创建或更新体检 Issue
5. Action 能识别 `/gitdocs sync ...` 评论命令
6. Action 能校验评论者是否具备 repo 写权限
7. Action 能为选定语言创建补翻译 PR
8. Action 能在后续 push 时只处理改动段落
9. Action 能保护代码块、front matter、链接 URL 和 MDX/JSX 结构
10. Action 能在 PR merge 后写入 active Translation Memory

第一批开发不做：

- 真实 Dashboard
- 多框架适配
- 自然语言命令
- 历史翻译质量审计
- 术语表
- 分享卡片

**Sprint 2：产品化保护**

- GitHub OAuth
- key 发放
- 用量统计
- 文档数/字数限制
- Translation Memory 读写
- 错误提示与重试

验收：新用户能注册、拿 key、接入 repo，并看到清楚的失败提示。

**Sprint 3：上线准备**

- 官网首页、定价页、接入文档、故障排查页、开源计划页
- README landing page
- demo repo
- PR branding 规则
- 开源计划限制与提示

验收：用户可以从官网或 README 完成自助接入。

### 11.3 MVP 成功指标

MVP 不以功能数量判断成功，而以目标用户是否进入同步流程判断成功。

核心指标：

| 指标 | 目标 |
|---|---|
| 首次接入完成率 | 用户能从 README/官网完成配置并生成体检 Issue |
| 体检到确认转化率 | 用户在体检 Issue 中评论 `/gitdocs` 命令 |
| 首个补翻译 PR 创建率 | 用户确认后成功创建至少一个目标语言 PR |
| 首个 PR merge 率 | 客户 merge 至少一个 GitDocs Sync 生成的翻译 PR |
| 增量同步成功率 | 后续源文档改动后能生成只包含改动段落的 PR |
| 超额拦截准确率 | 超过套餐或单文档上限时不自动翻译、不消耗额外额度 |
| 真实链路可运行 | demo repo 在 GitHub Actions 中完成体检 Issue、确认命令和翻译 PR 创建 |

MVP 不追求：

- 翻译质量自动评分
- 历史翻译质量审计
- Dashboard 活跃度
- 多框架覆盖数量
- 自然语言命令识别率

## 12. 后续迭代

### 高优先级

1. 多语言状态分享卡片
2. GitHub Marketplace 上架
3. 历史翻译 PR 页面
4. Team reviewer 管理
5. Translation Memory 查看与搜索

### 中优先级

1. 术语表
2. 翻译风格偏好
3. 自定义去抖时间
4. 多文档框架支持
5. 试用管理

### 低优先级

1. GitLab / Bitbucket
2. 语义 drift 检测
3. 翻译质量评分
4. 企业 SSO
5. 自托管版本

## 13. 关键产品判断

- 先占 Docusaurus 生态，不急着做全框架通用平台
- 第一版对外主打 “Auto-sync Docusaurus docs translations”，不在官网主卖点里限制源语言
- 第一版通过 `source_lang` 支持配置主语言，并持续观察非英语源语言检索和用户需求
- 第一版只承诺 Docusaurus Markdown / MDX 文档页，不承诺 JSON UI 文案、OpenAPI、Mintlify、Nextra 或 Starlight
- 第一版必须是真实可运行 GitHub Action 链路，demo repo 只能用于验证，不能替代产品
- 先把 PR 工作流做顺，不急着做 Dashboard
- 首次同步体检报告放在 GitHub Issue，不做 Dashboard 页面
- 首次同步范围通过 GitHub Issue 固定评论命令确认，不解析自然语言
- 只有具备 repo 写权限的成员可以用 Issue 命令触发补翻译，避免外部评论烧额度
- 首次同步体检只做 Missing / Untracked / Oversized / Ready 四类轻量判断，不做历史翻译质量审计
- 首次补翻译按目标语言分批创建 PR，每批最多 30 个文件，避免 review 和成本失控
- 先证明“只翻译改动部分”能省钱且可靠，不急着做术语表
- PR merge 由客户自行完成；merge 后才算翻译被接受
- Translation Memory 只记录 merge 后版本，避免把未确认翻译污染历史
- 超额时必须让客户选择，不自动截断
- 首次接入不自动全量翻译，先生成同步体检报告，让客户确认补翻译范围
- 开源是获客杠杆，不是付费主线
- 文档数量和单文档字数限制是成本保护，不是随意套餐包装
- MVP 优先做能推动客户进入同步流程的判断，不做高成本、低确定性的历史质量审计
- MVP 不做看起来高级但不直接推动试用、付费或留存的功能
- MVP 后台不长期保存客户文档正文或译文，降低商业团队接入顾虑
- TAM 约 1-2 万家目标公司，10% 渗透可形成约 3 万到 6 万美元 MRR，适合养 2-3 人团队，不按 VC 故事设计

## 14. 本版对 V1.0 的主要修正

| V1.0 表述 | V1.1 修正 |
|---|---|
| 目标用户包含开源维护者 | 核心用户改为文档即产品的商业团队，开源项目改为获客渠道 |
| 公开仓库自动享受 Pro 权益 | 改为按 star 分级，并要求 README/PR branding 交换 |
| Dashboard 相关能力接近 MVP | 分享卡、历史页、TM 管理后移 |
| 定价中出现“月限文档数”口径 | 统一为套餐文档数、单文档字数、仓库数、语言数限制 |
| 官网与产品功能边界混在一起 | 官网保留为自助接入和 SEO 入口，不扩张成产品工作台 |
