# GitDocs Sync

Auto-sync Docusaurus docs translations.

GitDocs Sync watches your Docusaurus docs in GitHub, translates only changed or missing Markdown/MDX docs, and opens translation PRs for your team to review. It is not a CMS and not a hosted docs site. It stays inside the Git workflow your team already uses.

## Who It Is For

GitDocs Sync is built for product and developer-tool teams where docs affect acquisition, activation, retention, and support quality.

It is a fit if:

- your docs are built with Docusaurus
- your docs live in GitHub
- you already have or want multiple language versions
- one or more translated versions regularly fall behind
- your team prefers reviewing docs changes through PRs

## What It Does

- scans your source docs
- creates a first-run translation audit Issue
- accepts repo-member commands such as `/gitdocs sync zh`
- translates missing or changed docs
- preserves Markdown front matter, code blocks, inline code, and link URLs
- opens translation PRs split into batches of 30 files
- writes Translation Memory only after PR merge
- commits Translation Memory back to the repo for future reuse
- opens a Translation Memory PR if branch protection blocks direct commits
- records privacy-safe usage metadata without storing source or translated document bodies
- shows provider and token usage in translation PRs when available

## Quick Start

Add `.gitdocs-sync.yml`:

```yml
source_lang: en
target_langs:
  - zh

docs_dir: docs/
output_dir: "i18n/{locale}/docusaurus-plugin-content-docs/current/"

ignore:
  - docs/changelog.md
  - docs/internal/**

dry_run: true
max_words_per_doc: 10000
```

Add `.github/workflows/gitdocs-sync.yml`:

```yml
name: GitDocs Sync

on:
  push:
    branches: [main]
    paths:
      - "docs/**/*.md"
      - "docs/**/*.mdx"
  issue_comment:
    types: [created]
  pull_request:
    types: [closed]

permissions:
  contents: write
  pull-requests: write
  issues: write

jobs:
  sync-docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: your-org/gitdocs-sync@main
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          dry_run: "true"
        env:
          DEEPSEEK_API_KEY: ${{ secrets.DEEPSEEK_API_KEY }}
          # Add OPENAI_API_KEY later when you enable non-Chinese target languages.
          # OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
```

For local development inside this repository, use `uses: ./`.

## First Run

1. Keep `dry_run: true`.
2. Run the workflow.
3. Open the audit Issue created by GitDocs Sync.
4. Comment one command:
   - `/gitdocs sync all`
   - `/gitdocs sync zh`
   - `/gitdocs sync zh,ja`
   - `/gitdocs future-only`
5. Switch to `dry_run: false` only when you are ready to create real translation PRs.

## Provider Keys

- Chinese directions use DeepSeek: add `DEEPSEEK_API_KEY`.
- Non-Chinese directions use OpenAI: add `OPENAI_API_KEY` later when you enable those target languages.

## Cost Protection

Oversized docs are skipped before translation. GitDocs Sync tells you to choose one of three options before retrying:

- split the file into smaller docs
- upgrade for a higher limit
- skip it

This keeps the MVP predictable and prevents one huge Markdown file from consuming the plan budget.

## Try The Demo

See `examples/docusaurus-demo`, `docs/github-test-repo-setup.md`, `docs/live-dry-run.md`, `docs/live-smoke-runbook.md`, and `docs/troubleshooting.md`.

## Development

Run tests:

```powershell
node.exe --test test\*.test.js
```
