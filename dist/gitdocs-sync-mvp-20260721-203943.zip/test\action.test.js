const assert = require("node:assert/strict");
const { mkdtempSync, writeFileSync } = require("node:fs");
const { join } = require("node:path");
const { tmpdir } = require("node:os");
const test = require("node:test");

const { createGitHubAdapterFromEnv, formatActionError, readGitHubEventFromFile } = require("../src/action");

test("action maps issue_comment payload to internal event", () => {
  const dir = mkdtempSync(join(tmpdir(), "gitdocs-action-"));
  const eventPath = join(dir, "event.json");
  writeFileSync(
    eventPath,
    JSON.stringify({
      issue: { number: 7, title: "[GitDocs Sync] Translation sync audit" },
      comment: { body: "/gitdocs sync zh", user: { login: "maintainer" } },
    }),
    "utf8",
  );

  const event = readGitHubEventFromFile("issue_comment", eventPath);

  assert.deepEqual(event, {
    name: "issue_comment",
    issue: { number: 7, title: "[GitDocs Sync] Translation sync audit" },
    comment: { body: "/gitdocs sync zh", user: "maintainer" },
  });
});

test("action maps push payload to changed docs", () => {
  const dir = mkdtempSync(join(tmpdir(), "gitdocs-action-"));
  const eventPath = join(dir, "event.json");
  writeFileSync(
    eventPath,
    JSON.stringify({
      commits: [
        { added: ["docs/intro.md"], modified: ["README.md"], removed: [] },
        { added: [], modified: ["docs/guide.md"], removed: ["docs/old.md"] },
      ],
    }),
    "utf8",
  );

  const event = readGitHubEventFromFile("push", eventPath);

  assert.deepEqual(event, {
    name: "push",
    changedFiles: ["docs/intro.md", "README.md", "docs/guide.md", "docs/old.md"],
  });
});

test("action maps push payload from head_commit when commits are unavailable", () => {
  const dir = mkdtempSync(join(tmpdir(), "gitdocs-action-"));
  const eventPath = join(dir, "event.json");
  writeFileSync(
    eventPath,
    JSON.stringify({
      commits: [],
      head_commit: {
        added: [],
        modified: ["docs/intro.md"],
        removed: [],
      },
    }),
    "utf8",
  );

  const event = readGitHubEventFromFile("push", eventPath);

  assert.deepEqual(event, {
    name: "push",
    changedFiles: ["docs/intro.md"],
  });
});

test("action explains when repository context is missing", () => {
  const previousRepository = process.env.GITHUB_REPOSITORY;
  const previousToken = process.env.GITHUB_TOKEN;
  delete process.env.GITHUB_REPOSITORY;
  process.env.GITHUB_TOKEN = "token";

  try {
    assert.throws(
      () => createGitHubAdapterFromEnv(),
      /GitDocs Sync needs the GitHub repository name/,
    );
  } finally {
    restoreEnv("GITHUB_REPOSITORY", previousRepository);
    restoreEnv("GITHUB_TOKEN", previousToken);
  }
});

test("action explains when github token is missing", () => {
  const previousRepository = process.env.GITHUB_REPOSITORY;
  const previousGithubToken = process.env.GITHUB_TOKEN;
  const previousInputToken = process.env.INPUT_GITHUB_TOKEN;
  process.env.GITHUB_REPOSITORY = "acme/docs";
  delete process.env.GITHUB_TOKEN;
  delete process.env.INPUT_GITHUB_TOKEN;

  try {
    assert.throws(
      () => createGitHubAdapterFromEnv(),
      /Pass github_token/,
    );
  } finally {
    restoreEnv("GITHUB_REPOSITORY", previousRepository);
    restoreEnv("GITHUB_TOKEN", previousGithubToken);
    restoreEnv("INPUT_GITHUB_TOKEN", previousInputToken);
  }
});

test("action error output includes stack context when available", () => {
  const error = new Error("GitHub request failed");
  error.stack = "Error: GitHub request failed\n    at useful-frame";

  assert.match(formatActionError(error), /useful-frame/);
});

function restoreEnv(name, value) {
  if (value === undefined) {
    delete process.env[name];
  } else {
    process.env[name] = value;
  }
}
